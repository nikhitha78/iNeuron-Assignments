CREATE DATABASE ACCIDENTS;
USE ACCIDENTS;

CREATE TABLE VEHICLE_TYPES
(
  VEHICLE_CODE INTEGER NOT NULL,
  VEHICLE_LABEL VARCHAR(100) NOT NULL );
  
LOAD DATA INFILE "D:/FSDA/02.UK Road Safty Accidents 2015/datasets/vehicle_types.csv"
INTO TABLE VEHICLE_TYPES
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES ;

select * from vehicle_types;

  CREATE TABLE VEHICLES(
	accident_index VARCHAR(13),
    vehicle_type VARCHAR(50)
);

LOAD DATA INFILE "D:/FSDA/02.UK Road Safty Accidents 2015/datasets/Vehicles_2015.csv"
INTO TABLE VEHICLES
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(@col1, @dummy, @col2, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy)
SET accident_index=@col1, vehicle_type=@col2;

select * from VEHICLES;

CREATE TABLE ACCIDENT(
	ACCIDENT_INDEX VARCHAR(13),
    accident_severity INT
);

LOAD DATA INFILE "D:/FSDA/02.UK Road Safty Accidents 2015/datasets/Accidents_2015.csv"
INTO TABLE ACCIDENT
FIELDS TERMINATED BY ","
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(@col1, @dummy, @dummy, @dummy, @dummy, @dummy, @col2, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy,@dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy)
SET accident_index=@col1, accident_severity =@col2;

SELECT * FROM ACCIDENT;

/*Accident Severity and Total Accidents per Vehicle Type*/
SELECT vt.VEHICLE_LABEL as vehicle_type , a.accident_severity as "accident_severity",  COUNT(vt.VEHICLE_LABEL) as "total accidents"
from ACCIDENT a 
JOIN VEHICLES v ON a.accident_index=v.accident_index
JOIN vehicle_types vt ON vt.VEHICLE_CODE=v.vehicle_type
GROUP BY 1
ORDER BY 2,3;

/* Average Severity by vehicle type */
SELECT vt.VEHICLE_LABEL as vehicle_type , avg(a.accident_severity) as avg_accident_severity
from ACCIDENT a 
JOIN VEHICLES v ON a.accident_index=v.accident_index
JOIN vehicle_types vt ON vt.VEHICLE_CODE=v.vehicle_type
GROUP BY 1
ORDER BY 2,3;


/* Average Severity and Total Accidents by Motorcyle */
SELECT vt.VEHICLE_LABEL as vehicle_type , avg(a.accident_severity) as avg_accident_severity,  COUNT(vt.VEHICLE_LABEL) as "number of vehicle types"
from ACCIDENT a 
JOIN VEHICLES v ON a.accident_index=v.accident_index
JOIN vehicle_types vt ON vt.VEHICLE_CODE=v.vehicle_type
WHERE vt.VEHICLE_LABEL LIKE '%otorcycle%'
GROUP BY 1
ORDER BY 2,3;


