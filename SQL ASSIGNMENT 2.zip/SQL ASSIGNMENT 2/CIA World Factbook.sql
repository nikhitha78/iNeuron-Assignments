CREATE DATABASE POPULATION;
USE POPULATION;

CREATE TABLE POPULATION(
country	VARCHAR(150),
area INTEGER,
birth_rate DECIMAL(38,3),
death_rate DECIMAL(38,3),
infant_mortality_rate DECIMAL(38,3),
internet_users	INTEGER,
life_exp_at_birth DECIMAL(38,3),
maternal_mortality_rate	INTEGER,
net_migration_rate	DECIMAL(38,3),
population	INTEGER,
population_growth_rate DECIMAL(38,3)
);

DROP TABLE POPULATION;

LOAD DATA INFILE "D:/FSDA/cia_factbook___FSDA 18th Sept 2022.csv"
INTO TABLE POPULATION
FIELDS TERMINATED BY ","
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

SELECT * FROM POPULATION; 

1. Which country has the highest population?

SELECT COUNTRY,POPULATION FROM POPULATION ORDER BY POPULATION DESC LIMIT 1;

2. Which country has the least number of people?

SELECT COUNTRY, POPULATION FROM POPULATION WHERE POPULATION >0 ORDER BY POPULATION LIMIT 1;

3. Which country is witnessing the highest population growth?

SELECT COUNTRY, population_growth_rate FROM POPULATION ORDER BY population_growth_rate DESC LIMIT 1;

4. Which country has an extraordinary number for the population? 
5. Which is the most densely populated country in the world? 

SELECT COUNTRY,POPULATION FROM POPULATION ORDER BY POPULATION DESC LIMIT 1;

